/*
Copyright © 2015 S. William & A.M. Pritchard
Licensed Under MIT
*/

/*
Includes Window Debounce Resize Function
Copyright © 2014 Louis-Rémi Babé - MIT Licensed - https://github.com/louisremi/jquery-smartresize
*/

/*
Download the plugin now at:
https://github.com/html5andblog/brick-by-brickJS

Documentation at:
http://html5andblog.github.io/brick-by-brick/

Co-Authored by:
http://www.html5andbeyond.com/

// use
$('#layout').layout({
    itemMargin : 5,
    itemPadding : 5
});


.single-column .b-by-b-item {
  width: 100%!important;
}
@media (min-width: 0px) and (max-width: 480px) {
  #layout .b-by-b-item {
    width: 100%;
  }
}
@media (min-width: 481px) and (max-width: 1024px) {
  #layout .b-by-b-item {
    width: 50%;
  }
}
@media (min-width: 1025px) {
  #layout .b-by-b-item {
    width: 33.33%;
  }
}

.b-by-b-item {
background-color: #ffa500;
}

*/

!function(n){function e(n,e){return onresize=function(){clearTimeout(e),e=setTimeout(n,100)},n}function i(){var e=n(".b-by-b-item").width(),i=100/(parseInt(e)/c.width()*100),t=Math.round(i);return t}function t(){u=c.children(".b-by-b-item"),u.remove(),n(d).appendTo(c),u.removeAttr("data-column"),n(".single-column").remove()}function r(n){n.css({padding:p.itemPadding,"margin-top":p.itemMargin,"margin-bottom":p.itemMargin,"box-sizing":"border-box"})}function a(e){for(var i=0;e>i;i++)c.prepend('<div class="single-column 1of'+e+'"></div>');c.children(".single-column").css({"float":"left",width:100/e+"%","padding-left":p.itemMargin/2,"padding-right":p.itemMargin/2,"box-sizing":"border-box"}),u=c.children(".b-by-b-item"),r(u);for(var i=0;e>i;i++)u.filter(function(n){return n%e===i}).attr("data-column",i);n.each(u,function(i,t){var r=("#"+n(t).attr("id"),n(t).attr("data-column")),a=".1of"+e+":eq("+r+")";n(this).appendTo(a)}),n(".b-by-b-item").fadeIn(500)}function o(){var e;e=c.prop("id").length>0?"#"+c.prop("id"):"."+c.prop("class"),n("head").append("<style>"+e+':after { content:""; display:table; clear:both; }</style>')}var d,s,c,u,f=null,l=1e3,p=null,h={init:function(r){var l,h;return p=n.extend({itemMargin:5,itemPadding:5},r),n(this).children("div, section, article, img, a").addClass("b-by-b-item"),c=n(this),u=c.children(".b-by-b-item"),c.css("width","100%"),d=u.clone(),f=d,s=u.clone(),e(function(){c.hasClass("no-grid")||(t(),h=i(),a(h)),c.css("width","100%")}),n(window).resize(),t(),l=i(),a(l),o(),this},addAfter:function(e){for(var o,u=0;u<e.length;u++){var l=n(e[u]).addClass("b-by-b-item");[].push.apply(f,n.makeArray(l)),[].push.apply(s,n.makeArray(l))}d=n.grep(f,function(n){return"undefined"!=typeof n}),t(),c.hasClass("no-grid")?r(c.children(".b-by-b-item")):(o=i(),a(o))},addBefore:function(e){for(var o,u=0;u<e.length;u++){var l=n(e[u]).addClass("b-by-b-item");[].unshift.apply(s,n.makeArray(l)),[].unshift.apply(f,n.makeArray(l))}d=n.grep(f,function(n){return"undefined"!=typeof n}),t(),c.hasClass("no-grid")?r(c.children(".b-by-b-item")):(o=i(),a(o))},removeItems:function(e,r){var o;"undefined"==typeof r&&(r=l),n.each(e,function(e,i){for(var t=0;t<s.length;t++)n(s[t]).is(i)&&(n(i).animate({opacity:0},r),s.splice(t,1),f.splice(t,1),t--)}),d=n.grep(f,function(n){return"undefined"!=typeof n}),setTimeout(function(){t(),c.hasClass("no-grid")||(o=i(),a(o))},r+1)},hideItems:function(e,r){var o;"undefined"==typeof r&&(r=l),n.each(e,function(e,i){for(var t=0;t<f.length;t++)n(i).animate({opacity:0},r),n(f[t]).is(i)&&(delete f[t],t--)}),d=n.grep(f,function(n){return"undefined"!=typeof n}),setTimeout(function(){t(),c.hasClass("no-grid")||(o=i(),a(o))},r+1)},showItems:function(e,o){"undefined"==typeof o&&(o=l);var u,p=s;n.each(e,function(e,i){for(var t=0;t<p.length;t++)n(p[t]).is(i)&&(f[t]=p[t])}),d=n.grep(f,function(n){return"undefined"!=typeof n}),t(),n.each(e,function(e,i){n(i).css("opacity",0)}),c.hasClass("no-grid")||(u=i(),a(u)),n.each(e,function(e,i){n(i).animate({opacity:1},o),r(n(i))})},reload:function(){var n;c.hasClass("no-grid")&&(c.removeClass("no-grid"),t(),n=i(),a(n))},end:function(){c.hasClass("no-grid")||(t(),c.addClass("no-grid"))}};n.fn.layout=function(e){return h[e]?h[e].apply(this,Array.prototype.slice.call(arguments,1)):"object"!=typeof e&&e?(n.error("Method "+e+" does not exist in Brick by Brick JS"),void 0):h.init.apply(this,arguments)}}(jQuery);
