<div id="comments">
	<?php wp_list_comments(); ?>
</div>

<div id="comment-form">
	<?php comment_form(); ?>
</div>
