<?php get_header(); ?>

<?php add_option( 'id', '555', '', 'yes' ); ?>

<div id="post">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

		    <h2><a href="<?php echo the_permalink() ?>"> <?php the_title()?> </a> </h2>

		    <p>		    	
		    <?php 
		    // show autor avatar
		    echo get_avatar( get_the_author_meta( $authordata->ID ), 256 ); 
		    $authordata = get_userdata( $authordata->ID );
		    ?>
		    

		    <a href="<?php echo get_author_link(false, $authordata->ID, $authordata->user_nicename); ?>"> <?php echo get_the_author(); ?></a>
		    <span class="entry-date"><?php echo get_the_date(); ?></span>
		    </p>


			<?php
			// display youtube video like first image
			if ( !has_post_thumbnail() ) { 
			    $text = get_the_content('');
			 	$m = "";
			 	if(preg_match_all(
			    '@(https?://)?(?:www\.)?(youtu(?:\.be/([-\w]+)|be\.com/watch\?v=([-\w]+)))\S*@im', $text, $m)){
			 		// matches found in $m
			 		 $text = $m[0][0];
				}
			    $text = strip_shortcodes( $text );
				echo preg_replace("/\s*[a-zA-Z\/\/:\.]*youtube.com\/watch\?v=([a-zA-Z0-9\-_]+)([a-zA-Z0-9\/\*\-\_\?\&\;\%\=\.]*)/i","<iframe width=\"420\" height=\"315\" src=\"//www.youtube.com/embed/$1\" frameborder=\"0\" allowfullscreen></iframe>",$text);
			}
		    ?>


		    <?php the_post_thumbnail('full'); ?>
		    <?php //the_post_thumbnail( 'single-post-thumbnail' ); ?>

			<?php the_excerpt(); ?>	

			<?php // the_content(__('Continue Reading')); ?>

			<?php
			$num = 0;	        
	       	$queried_post = get_post($post->ID);
	        $cc = $queried_post->comment_count;
	                if( $cc == $num || $cc > 1 ) : $cc = $cc.' Comments';
	                else : $cc = $cc.' Comment';
	                endif;
	        $permalink = get_permalink($post_id);

	        echo '<a href="'. $permalink . '" class="comments_link">' . $cc . '</a>';

			?>

			<?php
			// tagi from posts
			/*
			$tags = get_tags();

			$html = '<div class="post_tags">';
			foreach ( $tags as $tag ) {
				$tag_link = get_tag_link( $tag->term_id );
						
				$html .= "<a href='{$tag_link}' title='{$tag->name} Tag' class='{$tag->slug}'>";
				$html .= "{$tag->name}</a>";
			}
			$html .= '</div>';
			echo $html;
			*/
			 ?> 


			<?php
			// category name
			$categories = get_the_category();			
			foreach ( $categories as $category ) { 
			    esc_attr( $category->name ); 	
			    $category_id = get_cat_ID( $category->name  );		 
			    $link = get_category_link( $category_id );  
			    echo '<a href="'.$link.'" class="tags">'.$category->name.'</a>';
			}

			?>
			<hr>

			<?php 
			if ( has_post_thumbnail() ) { 
				// imsge url http://
				//the_post_thumbnail_url();
				//the_post_thumbnail_url( 'thumbnail' );       // Thumbnail (default 150px x 150px max)
				//the_post_thumbnail_url( 'medium' );          // Medium resolution (default 300px x 300px max)
				//the_post_thumbnail_url( 'large' );           // Large resolution (default 640px x 640px max)
				//the_post_thumbnail_url( 'full' );            // Full resolution (original size uploaded)
			} else{


			}
			?>


		<?php wp_reset_query(); ?>

		<?php endwhile; else: ?>
		<?php _e('Sorry, no posts matched your criteria.'); ?>
		<?php endif; ?>



        <div class="navigation">
        <?php //posts_nav_link(); ?>
        </div>

		<div class="navigation">
		<div class="alignleft"><?php //previous_posts_link( '&laquo; Previous Entries' ); ?></div>
		<div class="alignright"><?php //next_posts_link( 'Next Entries &raquo;', '' ); ?></div>
		</div>


		<div class="navigation">
		<?php
		global $wp_query;

		$big = 999999999; // need an unlikely integer

		echo paginate_links( array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, get_query_var('paged') ),	
			'total' => $wp_query->max_num_pages,
			'prev_text' => __('« Prev'),
			'next_text' => __('Next »'),	
		) );
		?>
		</div>
</div>

<div id="sidebar">
<?php get_sidebar(); ?>
</div>

<?php get_footer(); ?>


<?php // wp_list_categories('orderby=name&include=3,5,9,16'); ?> 
<?php // echo get_template_directory_uri();?>

<?php if (current_user_can( 'manage_options' ) && is_user_logged_in()) {
        // echo "ADMIN USER READY TO UPLOAD";
 } ?>
