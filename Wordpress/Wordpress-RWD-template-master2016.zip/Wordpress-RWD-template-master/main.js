$(document).ready(function(){
$(window).scroll(function () {
   
  var x = $(this).scrollTop();  
  if ( x > 200 ) {
    $( ".top" ).addClass( 'showtop' );
    $( ".top" ).fadeIn("slow");
  } else {
    $( ".top" ).removeClass( 'showtop' );
    //$( ".menu" ).animate({opacity: 1}, 1500);
  }

});

});
