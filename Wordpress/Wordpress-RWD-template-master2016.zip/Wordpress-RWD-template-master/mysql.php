<?php
// connect like this
//require_once(path/to/wp-config.php');
//mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

// or with wordpress https://codex.wordpress.org/Class_Reference/wpdb
global $wpdb;
// $results = $wpdb->get_results( 'SELECT * FROM wp_options WHERE option_id = 1', OBJECT );
// $mylink = $wpdb->get_row( "SELECT * FROM $wpdb->links WHERE link_id = 10", ARRAY_N );
// $posts = $wpdb->get_results("SELECT ID, post_title FROM wp_posts WHERE post_status = 'future' AND post_type='post' ORDER BY post_date ASC LIMIT 0,4");
// echo $wpdb->prefix. " ".$wpdb->get_charset_collate(). " " . $wpdb->users;

// select from database
$results = $wpdb->get_results( 'SELECT * FROM wp_options WHERE option_id = 1' );

// create table in database with prefix
$tb = 'CREATE TABLE '.$wpdb->prefix.'bbbccc (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
firstname VARCHAR(30) NOT NULL,
lastname VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP
)';

$res = $wpdb->get_results($tb);
print_r($res);
?>
