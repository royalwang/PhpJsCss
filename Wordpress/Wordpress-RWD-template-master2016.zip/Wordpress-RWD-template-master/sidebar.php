	<?php dynamic_sidebar('first-sidebar'); ?>
	<?php dynamic_sidebar('second-sidebar'); ?>
