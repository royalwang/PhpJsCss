<!DOCTYPE html>
<html>
<head>
	<title><?php bloginfo('title')?></title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url')?>">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/main.js"></script>
	<?php wp_head()?>
</head>
<body style="background: url(<?php background_image();?>) #<?php  echo get_background_color(); ?>">
<header>
	<div id="logo"><?php echo wp_get_attachment_image( get_option('logo') , 'full'); ?></div>
	<h1> <a href="<?php echo home_url('/') ?>"> <?php bloginfo('name'); ?> </a></h1>
	<h2> <a href="<?php echo home_url('/') ?>"> <?php bloginfo('description'); ?> </a></h2>
</header>
<nav>
<?php wp_nav_menu(); ?>
</nav>

<div class="top">
<li><?php echo wp_get_attachment_image( get_option('logo') , 'full'); ?></li>
<li><?php wp_nav_menu(); ?></li>
</div>
<div id="main">
<?php // echo esc_url( home_url( '/' ) ); echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>	

