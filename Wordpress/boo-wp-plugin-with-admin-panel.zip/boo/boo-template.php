<?php /* Template Name: Boo Plugin Template Page */ ?>
<?php get_header(); ?>
<div id="main">
<div id="container" style="padding-right: 10px; box-sizing: border-box; border-right: 1px solid #f60">
<div id="post" class="shopitems">
	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
		<?php // get title and content from custom page ?>
		<!-- <h2> <?php the_title()?></h2> -->
		<?php the_content(); ?>
	    <?php //the_post_thumbnail(); ?>
		<?php //the_excerpt(); ?>		
	<?php endwhile; else: ?>
	<?php  echo '';?>
	<?php endif; ?>
	<?php
	
	// Boo plugin shortcode	
	do_shortcode('[boo_go_run]'); 

	// show from database
	do_shortcode('[boo_show]'); 

	?>			
</div>
</div>
<div id="sidebar" style="padding-left: 10px;">
<?php get_sidebar(); ?>
</div>
</div><!-- container -->
<?php get_footer(); ?>
<?php wp_footer(); ?>