$( document ).ready(function() {	

	alert("BOO PLUGIN JS WORKS.....");
});