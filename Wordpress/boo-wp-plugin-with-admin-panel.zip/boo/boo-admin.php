<?php
// create menu plugin settings
// icon from link
// https://cdn4.iconfinder.com/data/icons/seo-and-data/500/gear-tools-settings-20.png

add_action('admin_menu','boo_plugin_menu');
function boo_plugin_menu(){

	// Show only if administrator
    if (current_user_can('administrator')) {
    // create top level menu for administrator
    add_menu_page('Boo settings', 'Fxstar Boo', 'administrator', 'Boo', 'Boo_plugin_settings_page' , 'https://cdn4.iconfinder.com/data/icons/seo-and-data/500/gear-tools-settings-20.png' );
    // create sub menu page
    add_submenu_page( 'Boo', 'About Plugin', 'About', 'administrator', 'About', 'Boo_plugin_about_page');
    }	

	// Show only if subscriber
    if (current_user_can('subscriber')) {
    // create top level menu for administrator
    add_menu_page('Boo settings', 'Fxstar Boo', 'subscriber', 'Boo', 'Boo_plugin_settings_page' , 'https://cdn4.iconfinder.com/data/icons/seo-and-data/500/gear-tools-settings-20.png' );
    // create sub menu page
    add_submenu_page( 'Boo', 'About Plugin', 'About', 'subscriber', 'About', 'Boo_plugin_about_page');
    }	    
}


// craeate plugin main page
function Boo_plugin_settings_page(){

    //plugin url
    $url = plugins_url().'/'.strtolower('boo');    

    // load style css from plugin url
    wp_register_style( 'style', $url.'/style.css' );
    wp_enqueue_style('style');

	echo '<div id="admin-top"> <h1> Hello from admin page</h1>';
	echo '<a class="boo-a">Hello from plugin page! Yoo nedd add here what you want (forms, database queries, php code as normal php code)</a>';

	?>

	<?php
	if ( isset($_POST["v_form2"]) ) {
		echo "<a> Your text from input: ".$_POST['txt'];
	}
	?>
	<form action="#v_form2" method="post" id="v_form2">
	<input type="text" name="txt" placeholder="Some text">
	<input type="submit" name="v_form2" value="<?php echo __('Show text','boo'); ?>" class="button-primary" />
	</from>

	<?php



	echo '</div>';
}

// create sub-page About sub-page
function boo_plugin_about_page(){
    echo '<h1 style="background: #fff; color: #192241; padding: 10px;">Fxstar.eu <br><br> <small style="color: #f60"> Wordpress templates and Woocommerce shops. </small> </h1>';
    echo '<a href="https://fxstar.eu" style="background: #f60; color: #fff; padding: 10px; text-decoration: none;"> https://fxstar.eu</a>';
}
?>