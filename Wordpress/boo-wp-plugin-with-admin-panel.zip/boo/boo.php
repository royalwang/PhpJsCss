<?php
/*
* Boo
*
* @package PluginPackage
* @autor Autor Name
* @copyright 2017 fxstar.eu
* @license Private
*
* @wordpress-plugin
* Plugin Name: Fxstar Boo
* Plugin URI: http://fxstar.eu
* Description: Boo plugin - plugin power
* Version: 1.0
* Author: fxstar.eu
* Author URI: https://fxstar.eu
* Text DOmain: boo
* Domain Path: /languages
*/

ob_start();
// session start
if(session_id() == '') session_start();

// security
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

// load languages files (internationalize plugin)
load_plugin_textdomain('boo', false, basename( dirname( __FILE__ ) ) . '/languages' );

// load functions boo_IP()
include('func.php');

// load custom pages
include('pages.php');

// load admin panel 
include('boo-admin.php');


// initialize plugin
add_action('init', 'boo_init');

function boo_init(){

	// get database global (connection to database)
	global $wpdb;

	// create table with prefix
	$table = $wpdb->prefix . 'boo_msg';
	// db charset
	$charset_collate = $wpdb->get_charset_collate();

	// create database table
	$sql = "CREATE TABLE IF NOT EXISTS $table (
	`id` bigint(22) NOT NULL AUTO_INCREMENT,
	`uid` bigint(22) NOT NULL DEFAULT 0,	
	`user` varchar(200),
	`msg` varchar(200),	
	`price` decimal(10,2),
	`active` char(1) DEFAULT '1',
	`time` int(21) DEFAULT 0,
	PRIMARY KEY (`id`)
	) $charset_collate;";

    
	// add unique key
	// # UNIQUE KEY `uid`(`uid`) i dont need here this line
	// # UNIQUE KEY `name`(`uid`,`msg`) i dont need here this line

	// now run query and create database in wordpress database
	// upgrade link
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );   
    dbDelta( $sql );	
}

// create plugin function 
function boo_go(){

    //plugin url
    $url = plugins_url().'/'.strtolower('boo');    
    $plugin_folder_path =  dirname(__FILE__);
    $wp_url = home_url();

    // load style css from plugin url
    wp_register_style( 'style', $url.'/style.css' );
    wp_enqueue_style('style');

    // load jquery
    wp_register_script( 'boo-scriptjq', $url.'/js/jquery.min.js');    
    wp_enqueue_script('boo-scriptjq'); 

    // use jquery from wordpress if needed with our js
    // wp_register_script( 'boo-script', $url.'/js/main-plugin.js', array( 'jquery' )); 
    wp_register_script( 'boo-script', $url.'/js/main-plugin.js', array( 'jquery' ));    
    wp_enqueue_script('boo-script'); 	


    if (isset($_POST['addmsg']) && !empty($_POST['user']) && !empty($_POST['msg'])) {
    	// add data to database 
    	// secure input
    	$user = htmlentities($_POST['user'], ENT_QUOTES, 'UTF-8');
    	$msg = htmlentities($_POST['msg'], ENT_QUOTES, 'UTF-8');
    	// if int variable you can do this $_POST[] or if you use from url links $_GET[]
    	// $id = (int)$_POST['uid'];
    	// from our func.php file
    	$ip =  boo_IP();

    	// insert to database
    	global $wpdb;
    	// table name with wp prefix
    	$table = $wpdb->prefix . 'boo_msg';
    	// insert
    	$wpdb->insert(
    		$table,
    		array(
    			'user' => $user,
    			'msg' => $msg,
    			'uid' => rand(123,321)
    		)
    	);

    	echo '<h2> User added </h2>';
    	// or use custom queries
    	// $wpdb->query("SELECT * FROM ".$table);
    	// $wpdb->get_results("SELECT * FROM ".$table);
    }


    // create form
    echo '<form action="#" method="post" enctype="multipart/form-data" id="boo">';
    // multiple languages __('WORD sentense to translate', 'Text-domain')
    echo '<label>'.__('Username','boo').'</label>';
    echo '<input type="text" name="user">';
	
    echo '<label>'.__('Message','boo').'</label>';
    echo '<input type="text" name="msg">';
        
    echo '<input type="submit" name="addmsg" value="'.__('Add message', 'boo').'">';
    echo '</form>';
}
// adds a shortcode, you can use: [boo_go_run] or php:  do_shortcode('[boo_go_run]'); 
add_shortcode('boo_go_run', 'boo_go');



function boo_show(){
	    echo "<h2> SELECT ALL MESSAGES </h2>";
    	global $wpdb;
    	// table name with wp prefix
    	$table = $wpdb->prefix . 'boo_msg';
    	//$res = $wpdb->get_results( $wpdb->prepare("SELECT * FROM ".$table." WHERE uid=%d;", 131) );
    	$res = $wpdb->get_results( "SELECT * FROM ".$table );
    	
    	foreach ($res as $v) {
    		echo '<p class="boo-user">'.$v->user.' '.$v->msg.'</p>';
    	}
    	//echo "<pre>";
    	//print_r($res);
    	//echo "</pre>";
}
// [boo_show]
add_shortcode('boo_show','boo_show');


// show login link or do something
function boo_login(){
    if (current_user_can('subscriber') || current_user_can('contributor') || current_user_can('author') || current_user_can('editor') || current_user_can('administrator')) {
    
    }else{
        echo '<p id="bazafirmlogin"> <a class="animated bounce" href="'.site_url().'/login/"> '.__('Add your company (Login or register)', 'bazafirm').'</a><p>';
    }     
}
// adds a shortcode you can use: [bazafirm_login]
add_shortcode('boo_login', 'boo_login');
?>