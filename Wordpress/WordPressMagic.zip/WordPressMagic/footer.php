</div>
<footer>
	<?php echo date('Y'); ?> Copyright not for idiots :) <?php  echo get_option( 'id' ); ?>
</footer>
</body>
</html>