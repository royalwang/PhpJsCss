<?php get_header(); ?>

<?php add_option( 'id', '555', '', 'yes' ); ?>

<div>
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

		    <h2><a href="<?php echo the_permalink() ?>"> <?php the_title()?> </a> </h2>
		    <p>
		     	
		     	<a href="<?php echo get_author_link(false, $authordata->ID, $authordata->user_nicename); ?>"> <?php echo get_the_author(); ?></a>
		    </p>
			<?php the_content(__('COntinue Reading')); ?>

		    <?php the_post_thumbnail(); ?>
  		<?php the_excerpt(); ?>	
		
		<?php endwhile; else: ?>
		<?php _e('Sorry, no posts matched your criteria.'); ?>
		<?php endif; ?>
		
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
