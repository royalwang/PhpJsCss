<div id="sidebar">
	<h1>Sidebar</h1>

	<?php dynamic_sidebar('first-sidebar'); ?>
	<?php dynamic_sidebar('second-sidebar'); ?>
</div>