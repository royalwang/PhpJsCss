<?php

register_sidebar(array(
		'name' => '1 Right sidebar',
		'id' => 'first-sidebar',
		'description' => 'first sidebar',
		'before_widget' => '<div>',
		'after_widget' => '</div>'
));

register_sidebar(array(
		'name' => '2 Right sidebar',
		'id' => 'second-sidebar',
		'description' => 'first sidebar',
		'before_widget' => '<div>',
		'after_widget' => '</div>'
));

?>