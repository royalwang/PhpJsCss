<!DOCTYPE html>
<html>
<head>
	<title><?php bloginfo('title')?></title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="<?php bloginfo('stylesheet_url')?>">
	<?php wp_head()?>
</head>
<body>
<header>
	<h1> <a href="<?php echo home_url('/') ?>"> <?php bloginfo('name') ?> </a></h1>
</header>
<nav>
	<?php wp_nav_menu(); ?>
</nav>
<div id="main">
	

