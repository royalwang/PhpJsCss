<?php get_header(); ?>
<div id="post">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

			<h2> <?php the_title()?></h2>
					    <?php the_post_thumbnail(); ?>
						<?php the_content(); ?>


			<?php
			// tagi from posts
			$tags = get_tags();

			$html = '<div class="post_tags">';
			foreach ( $tags as $tag ) {
				$tag_link = get_tag_link( $tag->term_id );
				
				//$html .= "<a href='{$tag_link}' title='{$tag->name} Tag' class='{$tag->slug}'>";		
				$html .= "<a href='{$tag_link}' title='{$tag->name} Tag' class='tags'>";
				$html .= "{$tag->name}</a>";
			}
			$html .= '</div>';
			echo $html;
			 ?> 

			<?php endwhile; else: ?>
		<?php _e('Sorry, no posts matched your criteria.'); ?>
		<?php endif; ?>

</div>
<div id="sidebar">
<?php get_sidebar(); ?>
</div>

<?php comments_template('', true); ?>	
<?php get_footer(); ?>
