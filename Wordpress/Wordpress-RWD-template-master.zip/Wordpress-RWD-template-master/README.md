# Wordpress RWD template 
 RWD wordpress template with admin panel. (WP version 4.4.2)
 
 Admin panel: Image upload(logo), color picker, save variables, background image, background color.
 You can change style, colors, fonts size, borders in one file style.css
 
 <h1>Start with worpress template development, this template can help you.</h1>
 Download and install theme https://github.com/fxstar/Wordpress-RWD-template/archive/master.zip 

![rwd](https://cloud.githubusercontent.com/assets/16883796/13044372/21fbe91a-d3ce-11e5-8ddb-0c2fd5849438.jpg)

![bez tytulu](https://cloud.githubusercontent.com/assets/16883796/13047639/be2d5316-d3e0-11e5-81ed-deeeed1cb8a3.jpg)

![rwd1](https://cloud.githubusercontent.com/assets/16883796/13044539/03ec84ba-d3cf-11e5-995e-c3da0b686737.jpg)

![rwd2](https://cloud.githubusercontent.com/assets/16883796/13044551/109b2540-d3cf-11e5-9493-236e22342046.jpg)

first image upload (logo image upload works)
![rwd4](https://cloud.githubusercontent.com/assets/16883796/13045018/6dec0cc6-d3d1-11e5-8e11-ca001fb9972b.jpg)

 Remember me, add my link(https://fxstar.eu) in footer or donate PayPal: hello@breakermind.com
 
Or if you don't like wordpress RWD html5 template https://fxstar.eu/rwd.html

You can add Gallery plugin http://lokeshdhakar.com/projects/lightbox2/ 
