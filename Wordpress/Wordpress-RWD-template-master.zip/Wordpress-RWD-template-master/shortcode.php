<?php
// [userip]
function display_user_ip() {
        $ip = $_SERVER['REMOTE_ADDR'];
        return $ip;
}
add_shortcode('userip', 'display_user_ip');

// [bartag foo="foo-value"]
function bartag_func( $atts ) {
    $a = shortcode_atts( array(
        'foo' => 'something',
        'bar' => 'something else',
    ), $atts );
    return "foo = {$a['foo']}";
}
add_shortcode( 'bartag', 'bartag_func' );


// [twitter]
function wptuts_first_shortcode($atts, $content=null){
    $post_url = get_permalink($post->ID);
    $post_title = get_the_title($post->ID);
    $tweet = '<a href="http://twitter.com/home/?status=Read ' . $post_title . ' at ' . $post_url . '">Share on Twitter</a>';
    return $tweet;
}
add_shortcode('twitter', 'wptuts_first_shortcode');


// [youtube id="_ggWarwhv9M" ]Check out this video![/youtube]
function wptuts_youtube($atts, $content=null){
     extract(shortcode_atts( array('id' => ''), $atts));
     $return = $content;
    if($content)
        $return .= "<br /><br />";
     
    $return .= '<iframe width="560" height="349" src="http://www.youtube.com/embed/' . $id . '" frameborder="0" allowfullscreen></iframe>';     
    return $return;  
}
add_shortcode('youtube', 'wptuts_youtube');


// most recent post
// [newestpost]
function wptuts_recentpost($atts, $content=null){ 
    $getpost = get_posts( array('number' => 1) );     
    $getpost = $getpost[0];     
    $return = $getpost->post_title . "<br />" . $getpost->post_excerpt . "…";     
    $return .= "<br /><a href='" . get_permalink($getpost->ID) . "'><em>read more →</em></a>";     
    return $return;    
}
add_shortcode('newestpost', 'wptuts_recentpost');



?>
