</div>
<footer>
 <?php echo date('Y'); ?> Copyright. All rights reserved.  <a href="https://fxstar.eu" style="color: #ccff55">Powered by fxstar.eu</a> <?php //echo get_option( 'id' ); ?>

<?php
//wp_nav_menu( array( 'theme_location' => 'footerarea' ) );
?>

<ul class="footerlinks">
<?php
wp_list_pages('title_li='); ?>
</ul>
<ul class="footerlinks">
<?php
wp_list_categories('title_li='); ?>
</ul>
</footer>
</body>
</html>
