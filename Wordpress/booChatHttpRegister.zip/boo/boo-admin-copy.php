<?php
// create menu plugin settings
// icon from link
// https://cdn4.iconfinder.com/data/icons/seo-and-data/500/gear-tools-settings-20.png

add_action('admin_menu','boo_plugin_menu');
function boo_plugin_menu(){

	// Show only if administrator
    if (current_user_can('administrator')) {
    // create top level menu for administrator
    add_menu_page('Fxstar Boo', 'Fxstar Boo',  'administrator', 'Boo', 'Boo_plugin_settings_page' , 'https://cdn4.iconfinder.com/data/icons/seo-and-data/500/gear-tools-settings-20.png' );

    // create sub menu page (rewname top level doubled menu)
    add_submenu_page( 'Boo', 'Messages', 'Messages', 'administrator', 'Msg', 'Boo_plugin_messages_page');

    // create sub menu page
    add_submenu_page( 'Boo', 'About', 'About', 'administrator', 'About', 'Boo_plugin_about_page');

    remove_submenu_page('Boo','Boo');
    }	

	// Show only if subscriber
    if (current_user_can('subscriber')) {
    // create top level menu for administrator
    add_menu_page('Boo settings', 'Fxstar Boo', 'subscriber', 'Boo', 'Boo_plugin_settings_page' , 'https://cdn4.iconfinder.com/data/icons/seo-and-data/500/gear-tools-settings-20.png' );

    // create sub menu page
    add_submenu_page( 'Boo', 'Messages Plugin', 'Messages', 'subscriber', 'Priv', 'Boo_plugin_messages_page');

    // create sub menu page
    add_submenu_page( 'Boo', 'About Plugin', 'About', 'subscriber', 'About', 'Boo_plugin_about_page');
    }	    

    add_action('admin_menu', 'boo_settings');
}

function boo_scripts(){
    //plugin url
    $url = plugins_url().'/'.strtolower('boo');    
    $plugin_folder_path =  dirname(__FILE__);
    $wp_url = home_url();

    // load style css from plugin url
    wp_register_style( 'style', $url.'/style.css' );
    wp_enqueue_style('style');

    // use jquery from wordpress if needed with our js   
    // load from footer
    wp_register_script( 'boo-script', $url.'/js/plugin.js', array( 'jquery' ), '1.0.0' , true);    
    wp_enqueue_script('boo-script');     
}
add_action('admin_enqueue_scripts', 'boo_scripts');

// boo settings
function boo_settings(){
        register_setting( 'boo-group', 'boo_option' );
        settings_fields( 'boo-group' );
        do_settings_sections( 'boo-group' );
}

// craeate plugin main page
function Boo_plugin_settings_page(){

	echo '<div id="admin-top"> <h1> Hello from admin page</h1>';
	echo '<a class="boo-a">Hello from plugin page! Yoo nedd add here what you want (forms, database queries, php code as normal php code)</a>';

	if ( isset($_POST["form1"]) ) {
		echo "<a> Your text from input: ".$_POST['txt'];
	}


    $content   = '';
    $editor_id = 'mycustomeditor';
 
    //wp_editor( $content, $editor_id );

	?>
    <!-- or use action="http://www.example.com/wp-admin/admin-post.php" -->
    <!-- or use action="options.php" -->
	<form action="#" method="post" id="form1">
	<input type="text" name="txt" placeholder="Some text">    
	<input type="submit" name="form1" value="<?php echo __('Show text','boo'); ?>" class="button-primary" />
	</from>

	<?php
	echo '</div>';
}

// create sub-page About sub-page
function boo_plugin_about_page(){
    echo '<h1 style="background: #fff; color: #192241; padding: 10px;">Fxstar.eu <br><br> <small style="color: #f60"> Wordpress templates and Woocommerce shops. </small> </h1>';
    echo '<a href="https://fxstar.eu" style="background: #f60; color: #fff; padding: 10px; text-decoration: none;"> https://fxstar.eu</a>';
}


function boo_plugin_messages_page(){
    if (is_user_logged_in()) {          
        $u = wp_get_current_user();
        $e = $u->user_email;
        $i = $u->ID;
        echo '
        <h3>'.__('Hmm...', 'boo').'</h3>
        <div id="chatbox"> 
        </div>

        <div id="chat"> 
        <h2>'.__('Write something...', 'boo').'</h2>
        <input type="hidden" name="chatemail" id="chatemail" value="'.$e.'">
        <input type="text" name="chatmsg" id="chatmsg" placeholder="Message..." value="">
        <a id="chatsend"> SEND </a> <a id="chaterror"></a>
        </div>
        ';
    }        
}

?>

