# sql www-fxstar.rhcloud.com

CREATE TABLE IF NOT EXISTS users (
`id` bigint(22) NOT NULL AUTO_INCREMENT,
`email` varchar(200),
`nick` varchar(50),
`pass` varchar(32),
`about` text,	
`ip` varchar(100),
`time` int(21) DEFAULT 0,
`active` char(1) DEFAULT '1',
PRIMARY KEY (`id`),
UNIQUE KEY `nick` (`nick`)
);

CREATE TABLE IF NOT EXISTS chat (
`id` bigint(22) NOT NULL AUTO_INCREMENT,
`fid` bigint(22) NOT NULL DEFAULT 0,	
`msg` varchar(200),	
`ip` varchar(100),
`time` int(21) DEFAULT 0,
`active` char(1) DEFAULT '1',
PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS priv (
`id` bigint(22) NOT NULL AUTO_INCREMENT,
`fid` bigint(22) NOT NULL DEFAULT 0,	
`tid` bigint(22) NOT NULL DEFAULT 0,	
`msg` varchar(200),	
`ip` varchar(100),
`active` char(1) DEFAULT '1',
`time` int(21) DEFAULT 0,
PRIMARY KEY (`id`)
);

INSERT INTO `www`.`users` (`id`, `nick`, `pass`, `email`, `about`, `ip`, `time`, `active`) VALUES (NULL, 'Boo', MD5('pass'), 'hello@breakermind.com', 'Hello from Max :)', '127.0.0.1', '0', '1');