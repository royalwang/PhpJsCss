Write wordpress plugin:

1) 