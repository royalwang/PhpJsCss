<?php
// Add custom page template for plugin
add_filter('page_template', 'boo_template');
function boo_template($page_template){
	// page slug
	if ( is_page( 'boo' ) ) {
		$page_template = dirname( __FILE__ ). '/boo-template.php';
	}
	return $page_template;
}

?>