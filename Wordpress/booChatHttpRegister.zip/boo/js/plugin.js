jQuery(document).ready(function($){
	//alert("JS works");
	$( "#chatsend" ).on( "click", function() {
		var msg = $.trim($("#chatmsg").val());
		var email = $.trim($("#chatemail").val());
		var nick = $.trim($("#privnick").val());
		var pass = $.trim($("#privpass").val());
		//alert(msg + " " + email);
		if (!!msg) {
			var url = "https://www-fxstar.rhcloud.com/?nick="+nick+"&pass="+pass+"&msg="+msg;
			$.get( url, function( data ) {
	  			//$( "#chatbox" ).append( '<p class="msg">'+data+'</p>' );
	  			if (data == '[SEND]') {
	  				$( "#chaterror" ).html("Message has been send.");
	  				$("#chatmsg").val('');
	  			}else{
	  				alert("Error login or password");
	  			}
			});

			/* get chat messages */
			var url1 = "https://www-fxstar.rhcloud.com/getmsg.php?nick="+nick+"&pass="+pass;
			$.get( url1, function( data1 ) {						
					$( "#chatbox" ).html("");  
		  			$.each( data1.messages, function( i, item) {
		  				//$( "#chatbox" ).append( '<p class="msg">ID '+data1.messages[1].id+' '+data1.messages[1].msg+'</p>' );
	  				if (item.msg.includes(nick)) {
	  					$( "#chatbox" ).prepend( '<p class="msgcolor"> <span>'+item.nick+'</span> '+item.msg+'</p>' );	
	  				}else{
	  					$( "#chatbox" ).prepend( '<p class="msg"> <span>'+item.nick+'</span> '+item.msg+'</p>' );
	  				}	
		  			$( "#chaterror" ).html("Show messages.");
					var objDiv = document.getElementById("chatbox");
					objDiv.scrollTop = objDiv.scrollHeight;		  				
		  			});
			}, "json" );	
		}	
	});

	function show_msg(){
		/* get chat messages */
		var nick = $.trim($("#privnick").val());
		var pass = $.trim($("#privpass").val());		
		var url1 = "https://www-fxstar.rhcloud.com/getmsg.php?nick="+nick+"&pass="+pass;
		$.get( url1, function( data1 ) {
				$( "#chatbox" ).html("");  			
	  			$.each( data1.messages, function( i, item) {
	  				if (item.msg.includes(nick)) {
	  					$( "#chatbox" ).prepend( '<p class="msgcolor"> <span>'+item.nick+'</span> '+item.msg+'</p>' );	
	  				}else{
	  					$( "#chatbox" ).prepend( '<p class="msg"> <span>'+item.nick+'</span> '+item.msg+'</p>' );
	  				}	  				
	  				$( "#chaterror" ).html("Show messages.");
					var objDiv = document.getElementById("chatbox");
					objDiv.scrollTop = objDiv.scrollHeight;		  				
	  			});
		}, "json" );
	};

	function send_msg(){
		var msg = $.trim($("#chatmsg").val());
		var email = $.trim($("#chatemail").val());
		var nick = $.trim($("#privnick").val());
		var pass = $.trim($("#privpass").val());		
		if (!!msg) {
		var url = "https://www-fxstar.rhcloud.com/?nick="+nick+"&pass="+pass+"&msg="+msg;
			$.get( url, function( data ) {				
	  			if (data == '[SEND]') {
	  				$( "#chaterror" ).html("Message has been send.");
	  				$("#chatmsg").val('');
	  			}else{
	  				alert("Error login or password.");
	  			};
			});
		};
	};



	$("#chatboxpriv").on( "click", ".msg", function() {		
		var usero = $(this).children("span").text();
		$("#chatuserpriv").val(usero);
		alert(use);	
	});

	$( "#chatsendpriv" ).on( "click", function() {
		var msg = $.trim($("#chatmsgpriv").val());
		var email = $.trim($("#chatemailpriv").val());
		var nick = $.trim($("#privnickpriv").val());
		var pass = $.trim($("#privpasspriv").val());
		var privnick = $.trim($("#chatuserpriv").val());

		//alert(privnick + " " + email);
		if (!!msg) {
			var url = "https://www-fxstar.rhcloud.com/sendmsgpriv.php?nick="+nick+"&pass="+pass+"&msg="+msg+"&privid="+privnick;
			$.get( url, function( data ) {
	  			if (data == '[SEND]') {
	  				$( "#chaterrorpriv" ).html("Message has been send.");
	  				$("#chatmsgpriv").val('');
	  			}else{
	  				alert("Error login or password 11");
	  			}
			});

			/* get priv messages */
			var url1 = "https://www-fxstar.rhcloud.com/getmsgpriv.php?nick="+nick+"&pass="+pass;
			$.get( url1, function( data1 ) {						
					$( "#chatboxpriv" ).html("");  
		  			$.each( data1.messages, function( i, item) {
		  				//$( "#chatbox" ).append( '<p class="msg">ID '+data1.messages[1].id+' '+data1.messages[1].msg+'</p>' );
	  				if (item.msg.includes(nick)) {
	  					$( "#chatboxpriv" ).prepend( '<p class="msgcolor"> <span>'+item.nick+'</span> '+item.msg+'</p>' );	
	  				}else{
	  					$( "#chatboxpriv" ).prepend( '<p class="msg"> <span>'+item.nick+'</span> '+item.msg+'</p>' );
	  				}	

					var objDiv = document.getElementById("chatboxpriv");
					objDiv.scrollTop = objDiv.scrollHeight;


		  				$( "#chaterrorpriv" ).html("Show messages.");
		  			});
			}, "json" );	
		}	
	});

	function show_msgpriv(){
		/* get chat messages */
		var nick = $.trim($("#privnickpriv").val());
		var pass = $.trim($("#privpasspriv").val());		
		var url1 = "https://www-fxstar.rhcloud.com/getmsgpriv.php?nick="+nick+"&pass="+pass;
		$.get( url1, function( data1 ) {
				$( "#chatboxpriv" ).html("");  			
	  			$.each( data1.messages, function( i, item) {
	  				if (item.msg.includes(nick)) {
	  					$( "#chatboxpriv" ).prepend( '<p class="msgcolor"> <span>'+item.nick+'</span> '+item.msg+'</p>' );	
	  				}else{
	  					$( "#chatboxpriv" ).prepend( '<p class="msg"> <span>'+item.nick+'</span> '+item.msg+'</p>' );
	  				}	  				
	  				$( "#chaterrorpriv" ).html("Show messages.");
	  				var objDiv = document.getElementById("chatboxpriv");
					objDiv.scrollTop = objDiv.scrollHeight;
	  			});
		}, "json" );
	};

	function send_msgpriv(){
		var msg = $.trim($("#chatmsgpriv").val());
		var email = $.trim($("#chatemailpriv").val());
		var nick = $.trim($("#privnickpriv").val());
		var pass = $.trim($("#privpasspriv").val());
		var privnick = $.trim($("#chatuserpriv").val());		
		if (!!msg) {
		var url = "https://www-fxstar.rhcloud.com/sendmsgpriv.php?nick="+nick+"&pass="+pass+"&msg="+msg+"&privid="+privnick;
			$.get( url, function( data ) {				
	  			if (data == '[SEND]') {
	  				$( "#chaterrorpriv" ).html("Message has been send.");
	  				$("#chatmsgpriv").val('');
	  			}else{
	  				alert("Error login or password.");
	  			};
			});
		};
	};


	setInterval(function(){ if(priv != 1){show_msg();} }, 3000);

	$(this).keypress(function(e) {
	    if(e.which == 13 && priv != 1) {
	       //alert("enter");
	       send_msg();
	       show_msg();
	    }
	});

	var priv = $("#priv").val();

	setInterval(function(){ if(priv == 1){show_msgpriv();} }, 3000);

	$(this).keypress(function(e) {
	    if(e.which == 13 && priv == 1) {
	       //alert("enter");
	       send_msgpriv();
	       show_msgpriv();
	    }
	});
	


	// register user
	$("#chatsendreg").click(function(){		
		var email = $.trim($("#regemail").val());
		var nick = $.trim($("#regnick").val());
		var pass = $.trim($("#regpass").val());	
		if (email != '' && nick != '' && pass != '') {
			//alert(email + nick + pass);			
			var url = "https://www-fxstar.rhcloud.com/register.php?nick="+nick+"&pass="+pass+"&email="+email;
			$.get( url, function( data ) {
	  			if (data == '[USER_ADD]') {
	  				$( "#chaterrorreg" ).html("User has been aded.");	  				
	  			}else if(data == '[ERROR_USERNAME_EMAIL_PASS]'){
	  				$( "#chaterrorreg" ).html("Incorrect email or username.");	
	  			}else{
	  				$( "#chaterrorreg" ).html("Error username exists");	  			
	  			}
			});
		}else{
			alert('form fields can not be empty');
		}
	});


	// reset user pass
	$("#chatsendres").click(function(){		
		var nick = $.trim($("#resnick").val());
		if (!!nick) {
			//alert(email + nick + pass);			
			var url = "https://www-fxstar.rhcloud.com/resetpass.php?nick="+nick;
			$.get( url, function( data ) {
				alert(data);
	  			if (data == '[SEND_MAIL]') {
	  				$( "#chaterrorres" ).html("New password was send on your email.");	  				
	  			}else{
	  				$( "#chaterrorres" ).html("Error user");	  			
	  			}
			});
		}else{
			alert('Form fields can not be empty');
		}
	});

});