<?php
// create menu plugin settings
// icon from link
// https://cdn4.iconfinder.com/data/icons/seo-and-data/500/gear-tools-settings-20.png

add_action('admin_menu','boo_plugin_menu');
function boo_plugin_menu(){

	// Show only if administrator
    if (current_user_can('administrator')) {
    // create top level menu for administrator
    add_menu_page('Fxstar Boo', 'Fxstar BooChat',  'administrator', 'Boo', 'Boo_plugin_settings_page' , 'https://cdn4.iconfinder.com/data/icons/seo-and-data/500/gear-tools-settings-20.png' );

    // create sub menu page
    add_submenu_page( 'Boo', 'Settings Plugin', 'Settings', 'administrator', 'BooSets', 'Boo_plugin_settings_page');

    // create sub menu page
    add_submenu_page( 'Boo', 'Chat page', 'Chat', 'administrator', 'BooChat', 'Boo_plugin_chat_page');

    // create sub menu page
    add_submenu_page( 'Boo', 'Priv page', 'Priv', 'administrator', 'BooPriv', 'Boo_plugin_priv_page');    

    // create sub menu page
    add_submenu_page( 'Boo', 'About page', 'About', 'administrator', 'BooAbout', 'Boo_plugin_about_page');

    remove_submenu_page('Boo','Boo');
    }	

	// Show only if subscriber
    if (current_user_can('subscriber')) {
    // create top level menu for administrator
    add_menu_page('Boo settings', 'Fxstar Boo', 'subscriber', 'Boo', 'Boo_plugin_settings_page' , 'https://cdn4.iconfinder.com/data/icons/seo-and-data/500/gear-tools-settings-20.png' );

    // create sub menu page
    add_submenu_page( 'Boo', 'Settings Plugin', 'Settings', 'subscriber', 'Sets', 'Boo_plugin_settings_page');

    // create sub menu page
    add_submenu_page( 'Boo', 'Chat page', 'Chat', 'administrator', 'BooChat', 'Boo_plugin_chat_page');

    // create sub menu page
    add_submenu_page( 'Boo', 'Priv page', 'Priv', 'administrator', 'BooPriv', 'Boo_plugin_priv_page');  

    // create sub menu page
    add_submenu_page( 'Boo', 'About Plugin', 'About', 'subscriber', 'About', 'Boo_plugin_about_page');
    }	    

    //add_action('admin_menu', 'boo_settings');
    //call register settings function
    add_action( 'admin_init', 'boo_settings' );
}

function boo_scripts(){
    //plugin url
    $url = plugins_url().'/'.strtolower('boo');    
    $plugin_folder_path =  dirname(__FILE__);
    $wp_url = home_url();

    // load style css from plugin url
    wp_register_style( 'boo-style', $url.'/style.css' );
    wp_enqueue_style('boo-style');

    // use jquery from wordpress if needed with our js   
    // load from footer
    wp_register_script( 'boo-script', $url.'/js/plugin.js', array( 'jquery' ), '1.0.0' , true);    
    wp_enqueue_script('boo-script');     
}
add_action('admin_enqueue_scripts', 'boo_scripts');

// boo settings
function boo_settings(){        
    register_setting( 'boo-group', 'boo_option' );    
    settings_fields( 'boo-group' );
    do_settings_sections( 'boo-group' );        
}

// craeate plugin main page
function Boo_plugin_settings_page(){

	echo '<div id="admin-top"> 
    <h2> '.__('Settings', 'boo').' </h2>';
	
	if ( isset($_POST["boo_form"]) ) {
		echo '<p class="plugin_success">'.__('Username and password has been saved.', 'boo').'</p>';
        $nick = htmlentities($_POST['boonick'], ENT_QUOTES, 'UTF-8');
        $pass = htmlentities($_POST['boopass'], ENT_QUOTES, 'UTF-8');
        $u = wp_get_current_user();        
        $userid = $u->ID;
        // save password and nickname
        $option["nick_".$userid] = $nick;
        $option["pass_".$userid] = $pass;
        // set in boo_option 
        $ser = serialize($option);
        add_option('boo_option', $ser);
        update_option('boo_option', $ser);
        $o = unserialize(get_option('boo_option'));

    }
	?>
    <!-- or use action="http://www.example.com/wp-admin/admin-post.php" -->
    <!-- or use action="options.php" -->
	<form action="#" method="post" id="boo_form">
    <?php
        $u = wp_get_current_user();        
        $userid = $u->ID;
        $o = unserialize(get_option('boo_option'));
    ?>
    <label><?php echo __('Username', 'boo'); ?></label>
	<input type="text" name="boonick" placeholder="" id="boonick" value="<?php echo esc_attr( $o["nick_".$userid] ); ?>">    
    <label><?php echo __('Password', 'boo'); ?></label>
    <input type="text" name="boopass" placeholder="" id="boopass" value="<?php echo esc_attr( $o["pass_".$userid] ); ?>">
	<input type="submit" name="boo_form" value="<?php echo __('Save','boo'); ?>" class="button-primary" />
	</from>

    <?php
    echo '<form id="boo_form">
    <h2>'.__('Register user', 'boo').'</h2>
    <label>'.__('Username', 'boo').'</label>
    <input type="text" name="regnick"  id="regnick" value=""> 
    <label>'.__('Email', 'boo').'</label>
    <input type="text" name="regemail" id="regemail" value="">  
    <label>'.__('Password', 'boo').'</label>
    <input type="text" name="regpass" id="regpass" value="">
    <a id="chatsendreg"> '.__('REGISTER', 'boo').' </a> <a id="chaterrorreg"></a>
    </form>';
    ?>

    <?php
    echo '<form id="boo_form">
    <h2>'.__('Reset password', 'boo').'</h2>
    <label>'.__('Username', 'boo').'</label>
    <input type="text" name="resnick"  id="resnick" value=""> 
    <a id="chatsendres"> '.__('RESET PASSWORD', 'boo').' </a> <a id="chaterrorres"></a>
    </form>';
    ?>    
	<?php
	echo '</div>';
}

// create sub-page About sub-page
function boo_plugin_about_page(){
    echo '<h1 style="background: #fff; color: #192241; padding: 10px;">Fxstar.eu <br><br> <small style="color: #f60"> Wordpress templates and Woocommerce shops. </small> </h1>';
    echo '<a href="https://fxstar.eu" style="background: #f60; color: #fff; padding: 10px; text-decoration: none;"> https://fxstar.eu</a>';
}


function boo_plugin_chat_page(){
    if (is_user_logged_in()) {          
        $u = wp_get_current_user();
        $e = $u->user_email;
        $i = $u->ID;
        $o = unserialize(get_option('boo_option'));
        echo '
        <h3>'.__('Chat', 'boo').'</h3>
        <div id="chatbox"> 
        </div>

        <div id="chat"> 
        <h2>'.__('Write something...', 'boo').'</h2>
        <input type="hidden" name="chatemail" id="chatemail" value="'.$e.'">
        <input type="hidden" name="privnick" id="privnick" value="'.esc_attr( $o["nick_".$i] ).'">
        <input type="hidden" name="privpass" id="privpass" value="'.esc_attr( $o["pass_".$i] ).'">        
        <input type="text" name="chatmsg" id="chatmsg" placeholder="" value="">
        <a id="chatsend"> '.__('SEND', 'boo').' </a> <a id="chaterror"></a>
        </div>
        ';         
    }        
}


function boo_plugin_priv_page(){
    if (is_user_logged_in()) {          
        $u = wp_get_current_user();
        $e = $u->user_email;
        $i = $u->ID;
        $o = unserialize(get_option('boo_option'));
        echo '
        <h3>'.__('Priv', 'boo').'</h3>
        <div id="chatboxpriv"> 
        </div>

        <div id="chatpriv"> 
        <h2>'.__('Username', 'boo').'</h2>
        <input type="hidden" name="chatemail" id="chatemailpriv" value="'.$e.'">
        <input type="hidden" name="priv" id="priv" value="1">
        <input type="hidden" name="privnick" id="privnickpriv" value="'.esc_attr( $o["nick_".$i] ).'">
        <input type="hidden" name="privpass" id="privpasspriv" value="'.esc_attr( $o["pass_".$i] ).'">
        <input type="text" name="chatuser" id="chatuserpriv" placeholder="User nick" value="">
        <h2>'.__('Message', 'boo').'</h2>
        <input type="text" name="chatmsg" id="chatmsgpriv" placeholder="" value="">
        <a id="chatsendpriv"> '.__('SEND', 'boo').' </a> <a id="chaterrorpriv"></a>
        </div>
        ';
    }        
}
?>

