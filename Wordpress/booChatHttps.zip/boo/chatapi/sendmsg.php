<?php
header('Content-Type: text/html; charset=utf-8');
header('Access-Control-Allow-Origin: *');
error_reporting('E_ALL');

// PDO
function Conn(){
$connection = new PDO('mysql:host=127.12.109.130;port=3306;dbname=www;charset=utf8', 'adminD3QJWNS', 'b8Mq2WuFPZ7d');
// don't cache query
$connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
// show warning text
$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
// throw error exception
$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// don't colose connecion on script end
$connection->setAttribute(PDO::ATTR_PERSISTENT, false);
// set utf for connection utf8_general_ci or utf8_unicode_ci 
$connection->setAttribute(PDO::MYSQL_ATTR_INIT_COMMAND, "SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci'");
return $connection;
}

// Function to get the client IP address
function IP() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    return $ipaddress;
}

// secure string
$nick = htmlentities($_GET['nick'], ENT_QUOTES, 'utf-8');
$pass = md5($_GET['pass']);
$msg = htmlentities($_GET['msg'], ENT_QUOTES, 'utf-8');
$tid = 0;
if (!empty($_GET['privid'])) {
	echo $tid = (int)$_GET['privid'];
}

// return 1 if exists or 0 user does not exists
function is_user($nick, $pass, $db){
	$res = $db->query("SELECT * FROM users WHERE nick = '$nick' AND pass='$pass'");
	//$rows = $res->fetchAll(PDO::FETCH_ASSOC);
	$cnt = 0;
	$cnt = $res->rowCount();
	return $cnt;
}

function send_msg($nick, $pass, $msg, $tid = 0, $db){
	$res = $db->query("SELECT * FROM users WHERE nick = '$nick' AND pass='$pass'");
	$rows = $res->fetchAll(PDO::FETCH_ASSOC);
	$fid = (int)$rows[0]['id'];
	$ip = IP();
	$time = time();
	if ($fid > 0 && $tid == 0) {
		$s = $db->query("INSERT INTO chat(fid,msg,ip,time) VALUES($fid, '$msg', '$ip', $time)");
		return $db->lastInsertId();
	}
	if ($fid > 0 && $tid != 0) {
		// get to id
		$res = $db->query("SELECT * FROM users WHERE nick = '$tid'");
		$rows = $res->fetchAll(PDO::FETCH_ASSOC);
		$tid = (int)$rows[0]['id'];
		if ($tid > 0) {
			$s = $db->query("INSERT INTO priv(fid,tid,msg,ip,time) VALUES($fid, $tid, '$msg', '$ip', $time)");
			return $db->lastInsertId();
		}
	}	
	return 0;
}


// show errors
try{
	
	// init db
	$db = Conn();

 	if (is_user($nick, $pass, $db) == 1) { 		
 		if(send_msg($nick, $pass, $msg, $tid, $db) > 0){
 			echo "[SEND]";
 		}
 	}else{
 		echo "[ERROR_LOGIN]";
 	}

  
} catch (Exception $e) {
    if ($e->getCode() == '2A000'){ echo "Syntax Error: ".$e->getMessage(); }
    //print_r($db->errorInfo());
  	//echo "PDO::errorCode(): ", $db->errorCode();
} 

?>