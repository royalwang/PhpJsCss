var _2MSYSTEM = _2MSYSTEM || {};

(function($){
	
	"use strict";
	
	_2MSYSTEM.initialize = {
		init: function()
		{
			_2MSYSTEM.initialize.defaults();
		},
		defaults: function()
		{
			$(window).load(function ()
			{
				$(".loader").fadeOut();
				$("#preloader").delay(350).fadeOut("slow");
			})
		}
	}
	
	_2MSYSTEM.documentOnReady = {
		init: function(){
			_2MSYSTEM.initialize.init();
		},
	};
	
	$(document).ready(_2MSYSTEM.documentOnReady.init);
	
})(jQuery);

$(document).ready(function()
{
	$(".onepage-pagination1 a").click(function()
	{
		if ($(this).hasClass("active") == true) { return false; }
		$(".onepage-pagination a.active").removeClass("active");
		$(this).addClass("active");
		var id_page = $(this).attr("data-index");
		changeSlide(id_page);
	});
	
	$(".onepage-pagination-top a").click(function()
	{
		if ($(this).hasClass("active") == true) { return false; }
		$(".onepage-pagination-top a.active").removeClass("active");
		$(".onepage-pagination a.active").removeClass("active");		
		$(this).addClass("active");		
		var index = $( ".onepage-pagination-top a" ).index( this );
		$(".onepage-pagination a").eq(index).addClass('active');
		//alert(index);
		var id_page = $(this).attr("data-index");
		changeSlide(id_page);
	});

	$(".onepage-pagination a").click(function()
	{
		if ($(this).hasClass("active") == true) { return false; }
		$(".onepage-pagination a.active").removeClass("active");
		$(".onepage-pagination-top a.active").removeClass("active");		
		$(this).addClass("active");		
		var index = $( ".onepage-pagination a" ).index( this );
		$(".onepage-pagination-top a").eq(index).addClass('active');
		//alert(index);
		var id_page = $(this).attr("data-index");
		changeSlide(id_page);
	});
	var isAnimating = false;
	var changeSlide = function(id_page)
	{
		if (isAnimating == true) { return false; }
		var outClass = "pt-page-rotateRoomTopOut pt-page-ontop", inClass = 'pt-page-rotateRoomTopIn';
				
				var animEndEventNames = {
					'WebkitAnimation' : 'webkitAnimationEnd',
					'OAnimation' : 'oAnimationEnd',
					'msAnimation' : 'MSAnimationEnd',
					'animation' : 'animationend'
				},
				animEndEventName = animEndEventNames[ Modernizr.prefixed( 'animation' ) ],
				endCurrPage = false,
				endNextPage = false,
				$currPage = $(".page-current"),
				$nextPage = $(".page-"+id_page),
				indexCurrent = $currPage.attr("data-index"),
				indexNext = $nextPage.attr("data-index"),
				support = Modernizr.cssanimations;
				
				if (indexNext < indexCurrent)
				{
					outClass = 'pt-page-rotateRoomBottomOut pt-page-ontop';
					inClass = 'pt-page-rotateRoomBottomIn';
				}
				

				$nextPage.addClass('page-current');
				$nextPage.find("h3").hide();
				$nextPage.find("p").hide();
				
				if(indexNext == 2)
				{
					$nextPage.find(".screen_stage_2").hide();
				}
				if(indexNext == 3)
				{
					$nextPage.find(".screen_stage_3").hide();
				}
				if(indexNext == 4)
				{
					$nextPage.find(".screen_stage_4").hide();
				}
				if(indexNext == 5)
				{
					$nextPage.find(".screen_stage_5").hide();
				}
				if(indexNext == 6)
				{
					$nextPage.find(".screen_stage_6").hide();
				}
				
				$currPage.addClass(outClass).on(animEndEventName, function()
				{
					isAnimating = true;
					$currPage.off(animEndEventName);
					endCurrPage = true;
					if(endNextPage)
					{
						onEndAnimation( $currPage, $nextPage );
					}
				});
				
				$nextPage.addClass(inClass).on(animEndEventName, function() {
					isAnimating = true;
					$nextPage.off(animEndEventName);
					endNextPage = true;
					if(endCurrPage)
					{
						onEndAnimation($currPage, $nextPage);
					}
				});
				
				if(!support)
				{
					onEndAnimation($currPage, $nextPage);
				}
				
				function onEndAnimation($outpage, $inpage)
				{
					endCurrPage = false;
					endNextPage = false;
					resetPage($outpage, $inpage);
					isAnimating = false;
					
					$nextPage.find("h3").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend',
						function()
						{
							$(this).removeClass();
						});
						
					setTimeout(function ()
					{ $nextPage.find("p").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass(); }); }, 500);
					
					if (indexNext == 2)
					{
						var screen_stage_2_height = $(".screen1").width();
						$(".screen_stage_2").css({'margin-left' : ((screen_stage_2_height/2)*-1)+'px'});
						
						
						setTimeout(function () { $(".screen1").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 500);
						setTimeout(function () { $(".screen3").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 700);
						setTimeout(function () { $(".screen2").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 900);
						setTimeout(function () { $(".screen4").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 1100);
						setTimeout(function () { $(".screen5").show().addClass("fadeIn animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeIn animated"); }); }, 1800);
						setTimeout(function () { $(".screen6").show().addClass("fadeIn animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeIn animated"); }); }, 2100);
						setTimeout(function () { $(".screen7").show().addClass("fadeIn animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeIn animated"); }); }, 2400);
					}
					
					if (indexNext == 3)
					{
						var screen_stage_3_height = $(".screen3_1").width();
						$(".screen_stage_3").css({'margin-left' : ((screen_stage_3_height/2)*-1)+'px'});
						
						setTimeout(function () { $(".screen3_2").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 500);
						setTimeout(function () { $(".screen3_3").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 700);
						setTimeout(function () { $(".screen3_1").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 900);
					}
					
					if (indexNext == 4)
					{
						var screen_stage_4_height = $(".screen4_1").width();
						$(".screen_stage_4").css({'margin-left' : ((screen_stage_4_height/2)*-1)+'px'});
						
						setTimeout(function () { $(".screen4_1").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 500);
						setTimeout(function () { $(".screen4_2").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 700);
						setTimeout(function () { $(".screen4_3").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 900);
						setTimeout(function () { $(".screen4_4").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 1100);
						setTimeout(function () { $(".screen4_5").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 1200);
						setTimeout(function () { $(".screen4_6").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 1300);
						setTimeout(function () { $(".screen4_7").show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 1500);
					}
					
					if (indexNext == 5)
					{
						var screen_stage_5_height = $(".screen5_1").width();
						$(".screen_stage_5").css({'margin-left' : ((screen_stage_5_height/2)*-1)+'px'});
						
						setTimeout(function () { $(".screen5_2").css({'z-index' : 1000}).show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 500);
						setTimeout(function () { $(".screen5_1").css({'z-index' : 1001}).show().addClass("fadeInDown animated").one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function() { $(this).removeClass("fadeInDown animated"); }); }, 700);
					}
					
					if (indexNext == 6)
					{
						var screen_stage_6_width = $(".screen6_1").width();
						var screen_stage_6_height = $(".screen6_1").height();
						$(".screen_stage_6").css({'opacity' : 0, 'bottom' : '-'+screen_stage_6_height+'px', 'margin-left' : ((screen_stage_6_width/2)*-1)+'px'});
						
						setTimeout(function () { $(".screen6_1").show().animate({'opacity' : 1, 'bottom' : 0}, 600) }, 500);
						setTimeout(function () { $(".screen6_2").show().animate({'opacity' : 1, 'bottom' : 0}, 600) }, 700);
					}
				}

				function resetPage( $outpage, $inpage ) {
					$outpage.attr('class', 'home page-'+$currPage.attr("data-index"));
					$inpage.attr('class', 'home page-'+$nextPage.attr("data-index")+' page-current');
				}
	}
	
	
	imageResize = function()
	{
		var h = $(window).height();
		var w = $(window).width();
		
		var resizeImageHeight = w * 1590 / 2400;
		var resizeImageWidth = w;
		var	positionTopImage = ((resizeImageHeight - h) / 2) * -1;
		var positionTopLeft = 0;
		
		if (positionTopImage > 0)
		{
			positionTopImage = 0;
			resizeImageHeight = h;
			resizeImageWidth = 2400 * h / 1590;
			positionTopLeft = ((resizeImageWidth - w) / 2) * -1;
		}
		
		percent_scale = resizeImageWidth / 2400;
		var video_width = percent_scale * 737;
		var video_left = (percent_scale * 867) + positionTopLeft;
		
		var video_height = percent_scale * 450;
		var video_top = (percent_scale * 343) + positionTopImage;
		
		$(".grass").css({'width' : resizeImageWidth+'px', 'left' : positionTopLeft+'px'});
		//$(".screen1, .screen2, .screen3").css({'width' : resizeImageWidth+'px', 'left' : positionTopLeft+'px'});
		
		var screen_stage_2_height = $(".screen1").width();
		$(".screen_stage_2").css({'margin-left' : ((screen_stage_2_height/2)*-1)+'px'});
		
		$(".movie").css({'top' : video_top+'px', 'left' : video_left+'px', 'width' : video_width+'px', 'height' : video_height+'px'});
		$(".movie video").css({'width' : video_width+'px', 'height' : video_height+'px'});
		
		//$(".home-bg img").css({'width' : resizeImageWidth+'px', 'height' : resizeImageHeight+'px', 'top' : positionTopImage+'px', 'left' : positionTopLeft+'px'});
	}
	
	//imageResize();
	
	$("body").on('mousewheel', function(event)
	{
		var curr = $(".page-current").attr("data-index");
		if (event.deltaY < 0)
		{
			var id_page = parseInt(curr) + 1;
		}
		else
		{
			var id_page = parseInt(curr) - 1;
		}
		alert(id_page);

		$(".onepage-pagination-top a.active").removeClass("active");
		$(".onepage-pagination a.active").removeClass("active");
		
		$(".onepage-pagination a").eq(id_page-1).addClass('active');
		$(".onepage-pagination-top a").eq(id_page-1).addClass('active');

		if (id_page > $(".onepage-pagination a").length) { id_page = 1; }
		if (id_page < 1) { id_page = $(".onepage-pagination a").length; }
		changeSlide(id_page);
	});
	
	$( window ).resize(function() { imageResize(); });
});