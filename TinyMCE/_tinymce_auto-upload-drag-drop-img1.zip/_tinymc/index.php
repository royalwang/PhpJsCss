<!DOCTYPE html>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src='tinymce.min.js'></script>
  <script>

      $( function() {
    var txt;

    $('body').on('mousemove','textarea',function(){
    txt = tinyMCE.activeEditor.getContent({format : 'raw'});
    $('#htmlcode').val(txt);
	});

	$("body").mousemove(function( event ) {		
		txt = tinyMCE.activeEditor.getContent({format : 'raw'});
		 $('#htmlcode').html(txt);
	});

	$('body').on('keyup','#htmlcode',function(){		
		var html = $(this).val();		
    htmlold.replace(/[\r\n]/g,'');
		tinyMCE.activeEditor.setContent(html, {format : 'raw'});
  	});

  	});

tinymce.init({
  selector: '#mytextarea',  // note the comma at the end of the line!
  visualblocks_default_state: true,
  autoresize_max_height: 500,
  height: '400',
  width: '100%',
  toolbar_items_size : 'small',
  plugins: 'textcolor colorpicker visualblocks codesample autoresize code image media advlist imagetools',  // note the comma at the end of the line!
  toolbar1: 'undo redo pastetext fontsizeselect forecolor backcolor visualblocks',
  toolbar2: 'codesample code image media advlist imagetools bullist numlist undo redo styleselect bold italic alignleft aligncenter alignright bullist numlist outdent indent',
  menubar: "tools code view",
  resize: "both",
  object_resizing : true,
  code_dialog_height: 100,
  code_dialog_width: 350,
  autoresize_bottom_margin: 50,
  advlist_bullet_styles: 'square',
  advlist_number_styles: 'lower-alpha,lower-roman,upper-alpha,upper-roman',
  font_formats: 'Arial=arial,helvetica,sans-serif;Courier New=courier new,courier,monospace;AkrutiKndPadmini=Akpdmi-n',
  fontsize_formats: '8pt 10pt 12pt 14pt 18pt 24pt 36pt',
  theme: 'modern',
  skin: 'lightgray',
  statusbar: false,
  
    
  //images_upload_url: 'postAcceptor.php',
  //images_upload_base_path: 'http://localhost/',
  // use cookies for image_upload_url
  images_upload_credentials: true,
  file_browser_callback_types: 'file image media',
  file_picker_types: 'file image media',
  //file_browser_callback : "myCustomFileBrowser",
  images_upload_handler: function (blobInfo, success, failure) {
    var xhr, formData;

    xhr = new XMLHttpRequest();
    xhr.withCredentials = false;
    xhr.open('POST', 'postAcceptor.php');

    xhr.onload = function() {
      var json;

      if (xhr.status != 200) {
        failure('HTTP Error: ' + xhr.status);
        return;
      }

      json = JSON.parse(xhr.responseText);

      if (!json || typeof json.location != 'string') {
        failure('Invalid JSON: ' + xhr.responseText);
        return;
      }

      success(json.location);
    };

    formData = new FormData();
    formData.append('file', blobInfo.blob(), blobInfo.filename());

    xhr.send(formData);
  },
  automatic_uploads: true,
  image_caption: true,
  image_title: true,
  color_picker_callback: function(callback, value) {
    callback('#FF00FF');
  },
  //file_browser_callback : function myFileBrowser (field_name, url, type, win) {   alert("Field_Name: " + field_name + "nURL: " + url + "nType: " + type + "nWin: " + win);  }
});

tinymce.activeEditor.uploadImages(function(success) {
   document.forms[0].submit();
});


</script>
  <style type="text/css">
	p img { max-width: 400px; height: auto }
	.ui-resize{
		border: 1px solid #000;
	}
	form{
		float: left;
		max-width: 40%;
		overflow: hidden;
		border: 3px solid #f23 !important;
	}
	#htmlcode{
		float: left;
		border: 1px solid #999;
		min-width: 49%;
		min-height: 300px;
		height: auto;
	}
	.mce-toolbar-grp {margin-left:3px; float:left; max-width: 300px; display: block;}

         .ui-widget-header {
            background:#b9cd6d;
            border: 1px solid #b9cd6d;
            color: #FFFFFF;
            font-weight: bold;
         }
         .ui-widget-content {
            background: #cedc98;
            border: 1px solid #DDDDDD;
            color: #333333;
         }
         .square {
            width: 150px;
            height: 150px;
            border: 1px solid black;
            text-align: center;
            float: left;
            margin-left: 20px;
            -right: 20px;
         }	


         ul{
         	float: left;
         	width: 100%;
         	height: auto;
         	overflow: hidden;
         	display: inline;
         }

         .defaultSkin table.mceLayout {border: 1px solid #000000;}
  </style>
</head>

<body>
<div class="top">
 <a class="btn">CODE</a>	
</div>
  <form method="post">
    <textarea id="mytextarea">Hello, World!</textarea>
  </form>  
  <textarea id="htmlcode"></textarea>	
  
<ul>
<?php
foreach (glob("images/*.{jpg,png,gif}", GLOB_BRACE) as $key => $value) {
	echo $key.' <img src="'.$value.'" width="50"> '.$value.'<br>';
}

?>
</ul>
</body>
</html>
